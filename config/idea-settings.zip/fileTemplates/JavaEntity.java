package ${PACKAGE_NAME};

import cn.togeek.foundation.data.entity.Subject;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "t_${NAME}")
@org.hibernate.annotations.Table(appliesTo = "t_${NAME}", comment = "￥DESC实体类说明")
public class ${NAME} extends Subject {
   @Column(name = "￥DESC字段名称_", columnDefinition = "￥DESC字段类型(￥DESC字段长度) COMMENT '￥DESC字段说明'")
   private ￥DESC变量类型 ￥DESC变量名称;
}