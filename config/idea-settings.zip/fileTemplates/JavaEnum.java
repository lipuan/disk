package ${PACKAGE_NAME};

public enum ${NAME} {
   private String name;

   ${NAME}(String name) {
      this.name = name;
   }
}