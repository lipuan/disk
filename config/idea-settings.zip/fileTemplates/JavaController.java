package ${PACKAGE_NAME};

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Api(tags = "￥DESC总体接口说明")
@RestController
@RequestMapping("/￥DESC总资源路径")
public class TestController {
   @Autowired
   private ￥DESC变量类型 ￥DESC变量名称;

   @ApiOperation("￥DESC具体接口说明")
   @ApiImplicitParams({@ApiImplicitParam(name = "￥DESC参数变量名称", value = "￥DESC参数说明")})
   @GetMapping("/￥DESC资源路径")
   public ￥DESC返回值类型 ￥DESC方法名称() {
      return null;
   }
}